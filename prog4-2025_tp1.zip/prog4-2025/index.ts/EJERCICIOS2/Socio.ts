class Socio {
    constructor(private_id: number, private_nombre: string, private_libros: Libro[] = []) {}
get id(){
    return this._id;
}

get nombre() {
    return this._nombre;
}
get apellido() {
    return this._apellido;
}
get nombreCompleto() {
    return `${this._nombre} ${this._apellido}`;
}



}


}