import { Libro } from "./Libro";
import { Socio } from "./Socio";
import { Autor } from "./Autor";
import { EventoBiblioteca } from "./EventoBiblioteca";

type Prestamo = {
    isbn: string;
    idSocio: number;
    fechaPrestamo: Date;
    fechaDevolucion?: Date;
};

export class Biblioteca {
    private inventario: Libro[] = [];
    private socios: Socio[] = [];
    private prestamos: Prestamo[] = [];
    private multas: Map<number, number> = new Map();
    private autores: Autor[] = [];
    private eventos: EventoBiblioteca[] = [];
    private notificaciones: Map<number, string[]> = new Map();
    private historialLectura: Map<number, string[]> = new Map(); // idSocio -> array de ISBNs

    agregarAutor(nombre: string, biografia: string, anioNacimiento: number): Autor {
        const autor = new Autor(nombre, biografia, anioNacimiento);
        this.autores.push(autor);
        return autor;
    }

    buscarAutorPorNombre(nombre: string): Autor | undefined {
        return this.autores.find(a => a.nombre === nombre);
    }

    agregarLibro(titulo: string, autor: Autor, isbn: string): Libro {
        const libro = new Libro(titulo, autor, isbn);
        this.inventario.push(libro);
        return libro;
    }

    buscarLibrosPorAutor(nombreAutor: string): Libro[] {
        return this.inventario.filter(libro => libro.autor.nombre === nombreAutor);
    }

    registrarSocio(id: number, nombre: string, apellido: string): Socio {
        const socioCreado = new Socio(id, nombre, apellido);
        this.socios.push(socioCreado);
        return socioCreado;
    }

    tieneMulta(idSocio: number): boolean {
        return (this.multas.get(idSocio) ?? 0) > 0;
    }

    prestarLibro(isbn: string, idSocio: number): string {
        const libro = this.inventario.find(l => l.isbn === isbn);
        if (!libro) return "Libro no encontrado";
        if (this.tieneMulta(idSocio)) return "El socio tiene multas pendientes y no puede tomar nuevos préstamos.";
        if (libro.prestado) {
            libro.agregarReserva(idSocio);
            return "Libro prestado, socio agregado a la cola de reservas";
        }
        libro.prestado = true;
        this.prestamos.push({
            isbn,
            idSocio,
            fechaPrestamo: new Date()
        });
        return "Libro prestado correctamente";
    }

    devolverLibro(isbn: string): string {
        const libro = this.inventario.find(l => l.isbn === isbn);
        if (!libro) return "Libro no encontrado";
        libro.prestado = false;

        const prestamo = this.prestamos.find(p => p.isbn === isbn && !p.fechaDevolucion);
        if (prestamo) {
            prestamo.fechaDevolucion = new Date();
            this.agregarAHistorial(prestamo.idSocio, isbn); // Guardar en historial
            const diasPrestamo = Math.ceil(
                (prestamo.fechaDevolucion.getTime() - prestamo.fechaPrestamo.getTime()) / (1000 * 60 * 60 * 24)
            );
            const diasPermitidos = 7;
            if (diasPrestamo > diasPermitidos) {
                const diasRetraso = diasPrestamo - diasPermitidos;
                const multa = diasRetraso * 50;
                const multaActual = this.multas.get(prestamo.idSocio) ?? 0;
                this.multas.set(prestamo.idSocio, multaActual + multa);
                this.notificarLibroVencido(prestamo.idSocio, libro.titulo);
            }
        }

        const siguienteSocio = libro.quitarReserva();
        if (siguienteSocio !== undefined) {
            libro.prestado = true;
            this.prestamos.push({
                isbn,
                idSocio: siguienteSocio,
                fechaPrestamo: new Date()
            });
            this.notificarReservaDisponible(siguienteSocio, libro.titulo);
            return `Libro devuelto. Notificar al socio con ID ${siguienteSocio} que el libro está disponible.`;
        }
        return "Libro devuelto correctamente";
    }

    reservarLibro(isbn: string, idSocio: number): string {
        const libro = this.inventario.find(l => l.isbn === isbn);
        if (!libro) return "Libro no encontrado";
        if (!libro.prestado) return "El libro está disponible, no es necesario reservarlo";
        libro.agregarReserva(idSocio);
        return "Reserva realizada correctamente";
    }

    mostrarReservas(isbn: string): number[] | string {
        const libro = this.inventario.find(l => l.isbn === isbn);
        if (!libro) return "Libro no encontrado";
        return libro.reservas;
    }

    consultarMulta(idSocio: number): number {
        return this.multas.get(idSocio) ?? 0;
    }

    pagarMulta(idSocio: number): string {
        if (!this.tieneMulta(idSocio)) return "El socio no tiene multas pendientes.";
        this.multas.set(idSocio, 0);
        return "Multa saldada correctamente.";
    }

    // --- Eventos y Notificaciones ---

    agregarEvento(nombre: string, descripcion: string, fecha: Date): EventoBiblioteca {
        const evento = new EventoBiblioteca(this.eventos.length + 1, nombre, descripcion, fecha);
        this.eventos.push(evento);
        return evento;
    }

    registrarSocioAEvento(idEvento: number, idSocio: number): string {
        const evento = this.eventos.find(e => e.id === idEvento);
        if (!evento) return "Evento no encontrado";
        evento.registrarSocio(idSocio);
        this.agregarNotificacion(idSocio, `Te has registrado al evento: ${evento.nombre}`);
        return "Socio registrado al evento correctamente";
    }

    notificarLibroVencido(idSocio: number, titulo: string) {
        this.agregarNotificacion(idSocio, `El libro "${titulo}" está vencido. Por favor, devuélvelo o paga la multa.`);
    }

    notificarReservaDisponible(idSocio: number, titulo: string) {
        this.agregarNotificacion(idSocio, `¡Tu reserva del libro "${titulo}" ya está disponible!`);
    }

    notificarEventoProximo(diasAntes: number = 1) {
        const hoy = new Date();
        this.eventos.forEach(evento => {
            const diff = (evento.fecha.getTime() - hoy.getTime()) / (1000 * 60 * 60 * 24);
            if (diff <= diasAntes && diff >= 0) {
                evento.sociosRegistrados.forEach(idSocio => {
                    this.agregarNotificacion(idSocio, `Recordatorio: El evento "${evento.nombre}" es pronto (${evento.fecha.toLocaleDateString()})`);
                });
            }
        });
    }

    agregarNotificacion(idSocio: number, mensaje: string) {
        if (!this.notificaciones.has(idSocio)) {
            this.notificaciones.set(idSocio, []);
        }
        this.notificaciones.get(idSocio)!.push(mensaje);
    }

    obtenerNotificaciones(idSocio: number): string[] {
        return this.notificaciones.get(idSocio) ?? [];
    }

    limpiarNotificaciones(idSocio: number) {
        this.notificaciones.set(idSocio, []);
    }

    // --- Historial de Lectura y Recomendaciones ---

    private agregarAHistorial(idSocio: number, isbn: string) {
        if (!this.historialLectura.has(idSocio)) {
            this.historialLectura.set(idSocio, []);
        }
        this.historialLectura.get(idSocio)!.push(isbn);
    }

    obtenerHistorialLectura(idSocio: number): string[] {
        return this.historialLectura.get(idSocio) ?? [];
    }

    recomendarLibros(idSocio: number): string[] {
        const historial = this.obtenerHistorialLectura(idSocio);
        if (historial.length === 0) return [];

        // Buscar autores y palabras clave de títulos leídos
        const autoresLeidos = new Set<string>();
        const palabrasClave: string[] = [];
        historial.forEach(isbn => {
            const libro = this.inventario.find(l => l.isbn === isbn);
            if (libro) {
                autoresLeidos.add(libro.autor.nombre);
                palabrasClave.push(...libro.titulo.toLowerCase().split(" "));
            }
        });

        // Recomendar libros no leídos del mismo autor o con palabras clave similares
        return this.inventario
            .filter(l => !historial.includes(l.isbn) &&
                (autoresLeidos.has(l.autor.nombre) ||
                 palabrasClave.some(palabra => l.titulo.toLowerCase().includes(palabra))))
            .map(l => l.titulo);
    }
}

export const biblioteca = new Biblioteca();