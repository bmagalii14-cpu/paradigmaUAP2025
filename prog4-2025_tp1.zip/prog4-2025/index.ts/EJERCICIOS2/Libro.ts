import { Autor } from "./Autor";

export class Libro {
    private _titulo: string;
    private _autor: Autor;
    private _isbn: string;
    private _prestado: boolean = false;
    private _reservas: number[] = [];

    constructor(titulo: string, autor: Autor, isbn: string) {
        this._titulo = titulo;
        this._autor = autor;
        this._isbn = isbn;
    }

    get titulo() { return this._titulo; }
    get autor() { return this._autor; }
    get isbn() { return this._isbn; }
    get prestado() { return this._prestado; }
    set prestado(valor: boolean) { this._prestado = valor; }

    agregarReserva(idSocio: number) {
        if (!this._reservas.includes(idSocio)) {
            this._reservas.push(idSocio);
        }
    }

    quitarReserva(): number | undefined {
        return this._reservas.shift();
    }

    get reservas(): number[] {
        return this._reservas;
    }
}