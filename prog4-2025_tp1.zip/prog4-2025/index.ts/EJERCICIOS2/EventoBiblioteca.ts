export class EventoBiblioteca {
    constructor(
        public id: number,
        public nombre: string,
        public descripcion: string,
        public fecha: Date,
        public sociosRegistrados: number[] = []
    ) {}

    registrarSocio(idSocio: number) {
        if (!this.sociosRegistrados.includes(idSocio)) {
            this.sociosRegistrados.push(idSocio);
        }
    }
}